/* LUMORA dashboard – vanilla JS + Chart.js + Lucide */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const money = n => '$' + n.toLocaleString('en-US');
  const initials = n => n.split(' ').map(w => w[0]).join('').slice(0, 2);
  const icons = () => lucide.createIcons();
  const badge = t => `<span class="badge b-${t.toLowerCase()}">${t}</span>`;
  const avatar = n => `<span class="avatar">${initials(n)}</span>`;

  // ---------- Sample data ----------
  const stats = [
    { label: 'Total Revenue', value: 128450, fmt: money, icon: 'wallet', change: 12.4 },
    { label: 'Total Users', value: 8420, fmt: n => n.toLocaleString(), icon: 'users', change: 8.1 },
    { label: 'Total Orders', value: 1893, fmt: n => n.toLocaleString(), icon: 'shopping-bag', change: -2.3 },
    { label: 'Conversion Rate', value: 3.8, fmt: n => n.toFixed(1) + '%', icon: 'target', change: 4.6 }
  ];
  const orders = [
    ['Sofia Laurent', 'LM-10482', 'Pro Annual Plan', 'Nov 09, 2026', 588, 'Paid'], ['Daniel Okafor', 'LM-10481', 'Team Seats ×5', 'Nov 09, 2026', 245, 'Pending'],
    ['Mia Tanaka', 'LM-10480', 'Starter Monthly', 'Nov 08, 2026', 19, 'Paid'], ['Lucas Meyer', 'LM-10479', 'Enterprise Setup', 'Nov 08, 2026', 1450, 'Paid'],
    ['Priya Nair', 'LM-10478', 'Pro Monthly', 'Nov 07, 2026', 59, 'Failed'], ['Ethan Brooks', 'LM-10477', 'Analytics Add-on', 'Nov 06, 2026', 89, 'Refunded'],
    ['Chloe Dubois', 'LM-10476', 'Team Seats ×10', 'Nov 06, 2026', 490, 'Paid'], ['Omar Haddad', 'LM-10475', 'Pro Annual Plan', 'Nov 05, 2026', 588, 'Pending'],
    ['Hannah Weiss', 'LM-10474', 'Starter Monthly', 'Nov 04, 2026', 19, 'Paid'], ['Noah Peters', 'LM-10473', 'Priority Support', 'Nov 03, 2026', 120, 'Failed']
  ].map(([name, id, product, date, amount, status]) => ({ name, id, product, date, amount, status }));
  const customers = [
    ['Sofia Laurent', 'sofia@laurent.io', 'Pro', 2940, 'Jan 2026'], ['Daniel Okafor', 'daniel@okafor.co', 'Team', 1960, 'Feb 2026'],
    ['Mia Tanaka', 'mia@tanaka.jp', 'Starter', 228, 'Mar 2026'], ['Lucas Meyer', 'lucas@meyer.de', 'Enterprise', 8700, 'Dec 2025'],
    ['Priya Nair', 'priya@nair.in', 'Pro', 708, 'May 2026'], ['Chloe Dubois', 'chloe@dubois.fr', 'Team', 2450, 'Apr 2026'],
    ['Omar Haddad', 'omar@haddad.ae', 'Pro', 1176, 'Jun 2026'], ['Hannah Weiss', 'hannah@weiss.at', 'Starter', 114, 'Aug 2026']
  ].map(([name, email, plan, spent, joined]) => ({ name, email, plan, spent, joined }));
  const projects = [
    ['Website Redesign', 'Refresh the marketing site and pricing page.', 72, 'Active', ['SL', 'DO', 'MT']], ['Mobile App v2', 'Native onboarding and offline mode.', 45, 'Active', ['LM', 'PN']],
    ['Billing Migration', 'Move subscriptions to the new provider.', 90, 'Review', ['CD', 'OH', 'HW']], ['Help Centre', 'Rewrite 60 support articles.', 100, 'Completed', ['EB', 'NP']],
    ['Partner API', 'Public endpoints and developer docs.', 28, 'Active', ['DO', 'LM', 'SL']], ['Brand Guidelines', 'Colour, type and tone of voice.', 60, 'Review', ['MT', 'CD']]
  ].map(([name, desc, progress, status, team]) => ({ name, desc, progress, status, team }));
  const notifs = [
    { t: 'New order LM-10482 from Sofia Laurent', ago: '5 min ago', unread: true, i: 'shopping-bag' }, { t: 'Payment failed for Priya Nair', ago: '1 hour ago', unread: true, i: 'circle-alert' },
    { t: 'Billing Migration is ready for review', ago: '3 hours ago', unread: true, i: 'folder-check' }, { t: 'Weekly report is available', ago: 'Yesterday', unread: false, i: 'file-text' }
  ];
  const activity = [['Sofia Laurent upgraded to Pro', '12 min ago'], ['Server backup completed', '1 hour ago'], ['Lucas Meyer opened a support ticket', '2 hours ago'], ['Invoice #8841 sent to Chloe Dubois', '5 hours ago'], ['Omar Haddad changed billing email', 'Yesterday']];
  const regs = [['Hannah Weiss', 'Starter', '2h ago'], ['Noah Peters', 'Pro', '5h ago'], ['Amelie Carter', 'Team', 'Yesterday'], ['Kenji Sato', 'Starter', 'Yesterday']];
  const threads = [
    { from: 'Sofia Laurent', sub: 'Question about annual billing', unread: true, msgs: [['in', 'Hi! Can I switch from monthly to annual mid-cycle?']] },
    { from: 'Lucas Meyer', sub: 'Enterprise onboarding call', unread: true, msgs: [['in', 'Could we move our onboarding call to Thursday?']] },
    { from: 'Mia Tanaka', sub: 'Invoice request', unread: true, msgs: [['in', 'Please send me the October invoice as a PDF.']] },
    { from: 'Chloe Dubois', sub: 'Thanks for the quick fix!', unread: false, msgs: [['in', 'Everything works now. Thank you!'], ['me', 'Glad to hear it, Chloe!']] }
  ];
  // Chart data per range
  const chartData = {
    weekly: { labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], revenue: [3200, 4100, 3800, 5200, 4900, 6100, 5400], sales: [42, 55, 48, 70, 66, 81, 73], users: [120, 150, 138, 190, 175, 230, 210] },
    monthly: { labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], revenue: [9800, 11200, 10400, 12900, 14100, 13600, 15800, 16900, 15200, 17800, 19400, 21000], sales: [310, 360, 340, 410, 450, 430, 500, 540, 490, 570, 610, 660], users: [420, 510, 560, 640, 720, 800, 910, 1010, 1100, 1230, 1340, 1480] }
  };
  const state = { q: '', status: 'all', range: 'weekly', view: 'dashboard', thread: 0 };
  const charts = {};

  // ---------- Toasts ----------
  function toast(msg) {
    const el = Object.assign(document.createElement('div'), { className: 'toast', textContent: msg });
    $('#toasts').append(el); setTimeout(() => el.remove(), 3000);
  }

  // ---------- Theme ----------
  function setTheme(t) {
    document.documentElement.dataset.theme = t;
    localStorage.setItem('lumora-theme', t);
    $('#theme-btn').innerHTML = `<i data-lucide="${t === 'dark' ? 'sun' : 'moon'}"></i>`;
    $('#set-dark').checked = t === 'dark';
    icons(); buildCharts();
  }

  // ---------- Stat cards with skeleton loading + count-up ----------
  function renderStats() {
    $('#stats').innerHTML = stats.map(s => `<article class="card stat loading"><span class="ico"><i data-lucide="${s.icon}"></i></span><small>${s.label}</small><strong>0</strong>
      <span class="delta ${s.change >= 0 ? 'up' : 'down'}"><i data-lucide="${s.change >= 0 ? 'trending-up' : 'trending-down'}"></i>${Math.abs(s.change)}% vs last month</span></article>`).join('');
    icons();
    setTimeout(() => $$('#stats .stat').forEach((card, i) => {
      card.classList.remove('loading');
      const el = $('strong', card), s = stats[i], t0 = performance.now();
      (function tick(now) {
        const p = Math.min((now - t0) / 900, 1);
        el.textContent = s.fmt(s.value * (1 - Math.pow(1 - p, 3)));
        if (p < 1) requestAnimationFrame(tick);
      })(t0);
    }), 900);
  }

  // ---------- Charts ----------
  const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  function buildCharts() {
    Object.values(charts).forEach(c => c.destroy());
    const d = chartData[state.range], ink = css('--muted'), grid = css('--line'), p = css('--p');
    const base = { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { backgroundColor: css('--solid'), titleColor: css('--ink'), bodyColor: css('--ink'), borderColor: grid, borderWidth: 1, padding: 12, cornerRadius: 12 } },
      scales: { x: { grid: { display: false }, ticks: { color: ink } }, y: { grid: { color: grid }, ticks: { color: ink }, border: { display: false } } } };
    const line = (id, data, label, fmt) => {
      const ctx = $(id).getContext('2d'), g = ctx.createLinearGradient(0, 0, 0, 300);
      g.addColorStop(0, 'rgba(139,124,246,.4)'); g.addColorStop(1, 'rgba(139,124,246,0)');
      return new Chart(ctx, { type: 'line', data: { labels: d.labels, datasets: [{ label, data, borderColor: p, backgroundColor: g, fill: true, tension: .4, borderWidth: 3, pointRadius: 0, pointHoverRadius: 6, pointBackgroundColor: p }] },
        options: { ...base, interaction: { intersect: false, mode: 'index' }, plugins: { ...base.plugins, tooltip: { ...base.plugins.tooltip, callbacks: { label: c => ' ' + fmt(c.parsed.y) } } } } });
    };
    charts.revenue = line('#revenue-chart', d.revenue, 'Revenue', money);
    charts.users = line('#users-chart', d.users, 'New users', n => n.toLocaleString() + ' users');
    charts.sales = new Chart($('#sales-chart'), { type: 'bar', data: { labels: d.labels, datasets: [{ label: 'Sales', data: d.sales, backgroundColor: p, hoverBackgroundColor: '#c58cf5', borderRadius: 10, borderSkipped: false, maxBarThickness: 34 }] }, options: base });
    $('#growth-stats').innerHTML = [['New users', d.users.reduce((a, b) => a + b)], ['Total sales', d.sales.reduce((a, b) => a + b)], ['Avg. order value', Math.round(d.revenue.reduce((a, b) => a + b) / d.sales.reduce((a, b) => a + b))]]
      .map(([l, v], i) => `<article class="card stat"><small>${l}</small><strong>${i === 2 ? money(v) : v.toLocaleString()}</strong></article>`).join('');
  }

  // ---------- Orders / customers (shared search + filter) ----------
  const match = (...f) => f.join(' ').toLowerCase().includes(state.q.toLowerCase());
  function renderOrders() {
    const rows = orders.filter(o => (state.status === 'all' || o.status === state.status) && match(o.name, o.id, o.product, o.status));
    $('#orders-body').innerHTML = rows.map((o, i) => `<tr style="animation-delay:${i * 30}ms"><td><span class="who-cell">${avatar(o.name)}${o.name}</span></td><td>${o.id}</td><td>${o.product}</td><td>${o.date}</td><td><b>${money(o.amount)}</b></td><td>${badge(o.status)}</td></tr>`).join('');
    $('#orders-empty').hidden = rows.length > 0;
  }
  function renderCustomers() {
    const rows = customers.filter(c => match(c.name, c.email, c.plan));
    $('#customers-body').innerHTML = rows.map(c => `<tr><td><span class="who-cell">${avatar(c.name)}${c.name}</span></td><td>${c.email}</td><td>${badge(c.plan)}</td><td><b>${money(c.spent)}</b></td><td>${c.joined}</td></tr>`).join('');
    $('#cust-empty').hidden = rows.length > 0;
  }
  function setQuery(q) {
    state.q = q; $('#global-search').value = q; $('#order-search').value = q;
    renderOrders(); renderCustomers();
  }

  // ---------- Static sections ----------
  function renderLists() {
    $('#timeline').innerHTML = activity.map(([t, a]) => `<li>${t}<small>${a}</small></li>`).join('');
    $('#registrations').innerHTML = regs.map(([n, p, a]) => `<li>${avatar(n)}<span class="grow"><b>${n}</b><small>${a}</small></span>${badge(p)}</li>`).join('');
    $('#transactions').innerHTML = orders.slice(0, 4).map(o => `<li>${avatar(o.name)}<span class="grow"><b>${o.name}</b><small>${o.id}</small></span><b>${money(o.amount)}</b>${badge(o.status)}</li>`).join('');
    $('#projects').innerHTML = projects.map(p => `<article class="card proj"><span class="badge b-${p.status.toLowerCase()}">${p.status}</span><h3>${p.name}</h3><p>${p.desc}</p>
      <div class="bar"><i style="width:0" data-w="${p.progress}%"></i></div><div class="meta"><span>${p.progress}% complete</span><span class="team">${p.team.map(avatar).join('')}</span></div></article>`).join('');
  }

  // ---------- Notifications ----------
  function renderNotifs() {
    $('#notif-list').innerHTML = notifs.map(n => `<li class="${n.unread ? 'unread' : ''}"><i data-lucide="${n.i}"></i><span>${n.t}<small>${n.ago}</small></span></li>`).join('');
    $('#notif-dot').hidden = !notifs.some(n => n.unread); icons();
  }
  function toggleMenu(btn, menu, force) {
    const open = force ?? menu.hidden;
    $$('.dropdown').forEach(m => { m.hidden = true; }); $$('[aria-expanded]').forEach(b => b.setAttribute('aria-expanded', 'false'));
    menu.hidden = !open; btn.setAttribute('aria-expanded', String(open));
  }

  // ---------- Messages ----------
  function renderThreads() {
    $('#msg-list').innerHTML = threads.map((t, i) => `<li class="${t.unread ? 'new' : ''} ${i === state.thread ? 'sel' : ''}" data-i="${i}">${avatar(t.from)}<span class="grow"><b>${t.from}</b><small>${t.sub}</small></span></li>`).join('');
    const t = threads[state.thread];
    $('#chat-title').textContent = `${t.from} · ${t.sub}`;
    $('#bubbles').innerHTML = t.msgs.map(([w, x]) => `<div class="bubble ${w === 'me' ? 'me' : ''}">${x}</div>`).join('');
    const unread = threads.filter(x => x.unread).length;
    $('#msg-count').textContent = unread; $('#msg-count').hidden = !unread;
  }

  // ---------- Navigation ----------
  function go(view) {
    state.view = view;
    $$('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + view));
    $$('.nav-item[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    closeSidebar(); window.scrollTo({ top: 0, behavior: 'smooth' });
    if (view === 'projects') setTimeout(() => $$('.bar i').forEach(i => { i.style.width = i.dataset.w; }), 60);
    if (view === 'analytics') buildCharts();
  }
  const closeSidebar = () => { $('#sidebar').classList.remove('open'); $('#scrim').classList.remove('show'); };
  function logout() { toast('Signed out (demo). Welcome back any time!'); go('dashboard'); }

  // ---------- Events ----------
  $('#nav').addEventListener('click', e => { const b = e.target.closest('[data-view]'); if (b) go(b.dataset.view); });
  $$('[data-go]').forEach(b => b.addEventListener('click', () => { go(b.dataset.go); toggleMenu($('#profile-btn'), $('#profile-menu'), false); }));
  $('#menu-btn').addEventListener('click', () => { $('#sidebar').classList.add('open'); $('#scrim').classList.add('show'); });
  $('#scrim').addEventListener('click', closeSidebar);
  $('#logout').addEventListener('click', logout); $('#logout2').addEventListener('click', logout);
  $('#theme-btn').addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
  $('#notif-btn').addEventListener('click', e => { e.stopPropagation(); toggleMenu($('#notif-btn'), $('#notif-menu')); });
  $('#profile-btn').addEventListener('click', e => { e.stopPropagation(); toggleMenu($('#profile-btn'), $('#profile-menu')); });
  $('#mark-read').addEventListener('click', () => { notifs.forEach(n => { n.unread = false; }); renderNotifs(); toast('All notifications marked as read'); });
  document.addEventListener('click', e => { if (!e.target.closest('.dd-wrap')) { $$('.dropdown').forEach(m => { m.hidden = true; }); $$('[aria-expanded]').forEach(b => b.setAttribute('aria-expanded', 'false')); } });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { $$('.dropdown').forEach(m => { m.hidden = true; }); closeSidebar(); } if (e.key === '/' && !/INPUT|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); $('#global-search').focus(); } });
  $('#global-search').addEventListener('input', e => { if (!['dashboard', 'customers'].includes(state.view)) go('dashboard'); setQuery(e.target.value); });
  $('#order-search').addEventListener('input', e => setQuery(e.target.value));
  $('#status-filter').addEventListener('change', e => { state.status = e.target.value; renderOrders(); });
  $$('[data-seg]').forEach(seg => seg.addEventListener('click', e => {
    const b = e.target.closest('[data-range]'); if (!b) return;
    state.range = b.dataset.range;
    $$('[data-seg] button').forEach(x => x.classList.toggle('on', x.dataset.range === state.range));
    buildCharts();
  }));
  $('#export-btn').addEventListener('click', () => {            // real CSV download of the (filtered) orders
    const rows = [['Customer', 'Order ID', 'Product', 'Date', 'Amount', 'Status'], ...orders.map(o => [o.name, o.id, o.product, o.date, o.amount, o.status])];
    const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(new Blob([rows.map(r => r.join(',')).join('\n')], { type: 'text/csv' })), download: 'lumora-orders.csv' });
    a.click(); URL.revokeObjectURL(a.href); toast('Report exported as CSV');
  });
  $('#msg-list').addEventListener('click', e => { const li = e.target.closest('li'); if (!li) return; state.thread = +li.dataset.i; threads[state.thread].unread = false; renderThreads(); });
  $('#reply-form').addEventListener('submit', e => {
    e.preventDefault(); const v = $('#reply-input').value.trim(); if (!v) return;
    threads[state.thread].msgs.push(['me', v.replace(/</g, '&lt;')]); $('#reply-input').value = ''; renderThreads();
    const box = $('#bubbles'); box.scrollTop = box.scrollHeight; toast('Reply sent');
  });
  $('#set-dark').addEventListener('change', e => setTheme(e.target.checked ? 'dark' : 'light'));
  $('#settings-form').addEventListener('submit', e => {
    e.preventDefault(); const name = $('#set-name').value.trim() || 'Amara Mensah';
    $('#user-name').textContent = name; $('#user-role').textContent = $('#set-role').value.trim() || 'Administrator';
    $('#welcome-name').textContent = name.split(' ')[0]; $$('.profile .avatar').forEach(a => { a.textContent = initials(name); }); toast('Settings saved');
  });

  // ---------- Init ----------
  $('#today').textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  renderLists(); renderOrders(); renderCustomers(); renderNotifs(); renderThreads(); renderStats();
  setTheme(localStorage.getItem('lumora-theme') || 'light');
})();
