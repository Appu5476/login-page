/* NOVA – Contact page (vanilla JS + Lucide).
   Real message delivery uses Formspree: set FORM_ENDPOINT below. */
(() => {
  'use strict';

  /* ---------- Configuration ----------
     1. Create a free form at https://formspree.io  2. Copy its endpoint, e.g. https://formspree.io/f/abcdwxyz
     3. Paste it below. While it still contains YOUR_FORM_ID the page runs in DEMO mode (nothing is sent).
     Newsletter signups use NEWSLETTER_ENDPOINT (create a second Formspree form, or reuse the same one). */
  const FORM_ENDPOINT = 'https://formspree.io/f/YOUR_FORM_ID';
  const NEWSLETTER_ENDPOINT = FORM_ENDPOINT;
  const MAX_CHARS = 600;

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const icons = () => lucide.createIcons();
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const isDemo = url => url.includes('YOUR_FORM_ID');

  /* ---------- Toasts ---------- */
  function toast(msg, type = 'info') {
    const t = Object.assign(document.createElement('div'), { className: 'toast ' + type, textContent: msg });
    $('#toasts').append(t); setTimeout(() => t.remove(), 4200);
  }

  /* ---------- Theme (persisted) ---------- */
  function setTheme(t) {
    document.documentElement.dataset.theme = t; localStorage.setItem('nova-theme', t);
    $('#theme-btn').innerHTML = `<i data-lucide="${t === 'dark' ? 'sun' : 'moon'}"></i>`; icons();
  }
  $('#theme-btn').addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));

  /* ---------- Mobile menu ---------- */
  const burger = $('#burger'), links = $('#links');
  const toggleMenu = open => { links.classList.toggle('open', open); burger.setAttribute('aria-expanded', open); burger.innerHTML = `<i data-lucide="${open ? 'x' : 'menu'}"></i>`; icons(); };
  burger.addEventListener('click', () => toggleMenu(!links.classList.contains('open')));
  links.addEventListener('click', e => { if (e.target.closest('a')) toggleMenu(false); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') toggleMenu(false); });

  /* ---------- Scroll effects: sticky nav, back-to-top, active link, reveal ---------- */
  const nav = $('#nav'), top = $('#to-top');
  const onScroll = () => { nav.classList.toggle('scrolled', scrollY > 20); top.classList.toggle('show', scrollY > 400); };
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  top.addEventListener('click', () => scrollTo({ top: 0, behavior: 'smooth' }));

  const spy = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) $$('.links a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + e.target.id));
  }), { rootMargin: '-45% 0px -50% 0px' });
  ['home', 'about', 'services', 'contact'].forEach(id => spy.observe($('#' + id)));
  const rev = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); rev.unobserve(e.target); } }), { threshold: .12 });
  $$('.reveal').forEach(el => rev.observe(el));

  /* ---------- Validation helpers ---------- */
  function setError(input, msg) {
    const f = input.closest('.field');
    f.classList.remove('bad'); void f.offsetWidth;            // restart shake animation
    f.classList.toggle('bad', !!msg); f.classList.toggle('good', !msg && !!input.value.trim());
    $('.err', f).textContent = msg || ''; return !msg;
  }
  const rules = {
    name: i => setError(i, i.value.trim().length < 2 ? 'Please enter your full name.' : ''),
    email: i => setError(i, !i.value.trim() ? 'Email is required.' : !EMAIL_RE.test(i.value.trim()) ? 'Enter a valid email address.' : ''),
    phone: i => { const d = i.value.replace(/\D/g, ''); return setError(i, i.value.trim() && (!/^\+?[\d\s().-]+$/.test(i.value.trim()) || d.length < 8 || d.length > 15) ? 'Enter a valid phone number (8–15 digits).' : ''); },
    subject: i => setError(i, i.value.trim().length < 3 ? 'Please add a short subject.' : ''),
    message: i => setError(i, i.value.trim().length < 10 ? 'Your message should be at least 10 characters.' : ''),
    privacy: i => setError(i, i.checked ? '' : 'Please accept the Privacy Policy to continue.')
  };

  /* ---------- Contact form ---------- */
  const form = $('#contact-form'), btn = $('#submit-btn'), msg = $('#message');
  const fields = Object.keys(rules).map(id => $('#' + id));
  const updateCount = () => { const n = msg.value.length; $('#count').textContent = `${n} / ${MAX_CHARS}`; $('#count').classList.toggle('warn', n > MAX_CHARS * .9); };
  msg.addEventListener('input', updateCount);
  fields.forEach(i => {
    i.addEventListener('blur', () => { if (i.value || i.type === 'checkbox') rules[i.id](i); });
    i.addEventListener('input', () => { if (i.closest('.field').classList.contains('bad')) rules[i.id](i); });
  });
  $('#privacy').addEventListener('change', e => rules.privacy(e.target));

  // Send JSON to Formspree (or simulate when not configured)
  async function send(endpoint, data) {
    if (isDemo(endpoint)) { await new Promise(r => setTimeout(r, 1200)); return { demo: true }; }
    const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(data) });
    if (!res.ok) { const j = await res.json().catch(() => ({})); throw new Error(j.errors?.map(e => e.message).join(', ') || 'Server error ' + res.status); }
    return res.json();
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    if (fields.map(i => rules[i.id](i)).includes(false)) {     // run all rules so every error shows
      toast('Please fix the highlighted fields.', 'error'); $('.bad input, .bad textarea', form)?.focus(); return;
    }
    btn.disabled = true; btn.classList.add('loading');
    try {
      const data = Object.fromEntries(new FormData(form)); data.privacy_accepted = true;
      if (data._gotcha) return;                                 // honeypot filled: silently drop bots
      const r = await send(FORM_ENDPOINT, data);
      toast(r.demo ? 'Demo mode: message validated but not sent. Add your Formspree endpoint in contact.js.' : 'Thanks! Your message was sent. We will reply soon.', 'success');
      form.reset(); $$('.field', form).forEach(f => f.classList.remove('good', 'bad')); updateCount();
    } catch (err) {
      toast('Could not send your message: ' + (err.message || 'network error') + '. Please try again.', 'error');
    } finally { btn.disabled = false; btn.classList.remove('loading'); }
  });

  /* ---------- Newsletter ---------- */
  $('#news-form').addEventListener('submit', async e => {
    e.preventDefault(); const i = $('#news-email'), b = $('.btn', e.target);
    if (!EMAIL_RE.test(i.value.trim())) { toast('Enter a valid email to subscribe.', 'error'); i.focus(); return; }
    b.disabled = true;
    try { const r = await send(NEWSLETTER_ENDPOINT, { email: i.value.trim(), form: 'newsletter' }); toast(r.demo ? 'Demo mode: subscription simulated.' : 'You are subscribed. Welcome aboard!', 'success'); i.value = ''; }
    catch (err) { toast('Subscription failed: ' + err.message, 'error'); }
    finally { b.disabled = false; }
  });

  /* ---------- FAQ accordion (one open at a time) ---------- */
  $('#faq-list').addEventListener('click', e => {
    const b = e.target.closest('.qa > button'); if (!b) return;
    const item = b.parentElement, open = !item.classList.contains('open');
    $$('.qa').forEach(q => { q.classList.remove('open'); $('button', q).setAttribute('aria-expanded', 'false'); });
    item.classList.toggle('open', open); b.setAttribute('aria-expanded', open);
  });

  /* ---------- Dialogs: login + privacy/terms ---------- */
  const docs = {
    privacy: ['Privacy Policy', '<p>We use the details you submit only to answer your message. We never sell your information.</p><p>Messages are delivered through our form provider and can be deleted on request: email support@nova.com.</p>'],
    terms: ['Terms of Service', '<p>By using NOVA you agree to use the service lawfully and respect other users.</p><p>This is sample text for a demo website; replace it with your own terms.</p>']
  };
  function openDoc(k) { $('#doc-title').textContent = docs[k][0]; $('#doc-body').innerHTML = docs[k][1]; $('#doc-dialog').showModal(); }
  $('#privacy-link').addEventListener('click', e => { e.preventDefault(); openDoc('privacy'); });
  $$('.legal').forEach(a => a.addEventListener('click', e => { e.preventDefault(); openDoc(a.dataset.doc); }));
  $('#login-btn').addEventListener('click', () => $('#login-dialog').showModal());
  $$('dialog').forEach(d => { d.addEventListener('click', e => { if (e.target === d || e.target.closest('[data-close]')) d.close(); }); });
  $('#login-form').addEventListener('submit', e => {
    e.preventDefault(); const em = $('#l-email'), pw = $('#l-pass');
    const ok = [setError(em, EMAIL_RE.test(em.value.trim()) ? '' : 'Enter a valid email.'), setError(pw, pw.value.length >= 6 ? '' : 'Password must be at least 6 characters.')];
    if (ok.includes(false)) return;
    $('#login-dialog').close(); e.target.reset(); $$('.field', e.target).forEach(f => f.classList.remove('good'));
    toast('Login is a demo here: connect it to your account system.', 'info');
  });

  /* ---------- Init ---------- */
  $('#year').textContent = new Date().getFullYear();
  setTheme(localStorage.getItem('nova-theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  updateCount();
})();
