/* Harbor – demo login & registration (vanilla JS).
   NOTE: localStorage is NOT secure storage. This is a front-end demo only. */
(() => {
  'use strict';

  // ---------- Helpers ----------
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const USERS_KEY = 'harbor_users', SESSION_KEY = 'harbor_session', REMEMBER_KEY = 'harbor_remembered_email';

  // Simple non-cryptographic hash so passwords aren't stored as plain text in the demo.
  const hash = (str) => {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0;
    return h.toString(36);
  };

  // ---------- Storage ----------
  const getUsers = () => { try { return JSON.parse(localStorage.getItem(USERS_KEY)) || []; } catch { return []; } };
  const saveUsers = (u) => localStorage.setItem(USERS_KEY, JSON.stringify(u));
  const findUser = (email) => getUsers().find(u => u.email === email.trim().toLowerCase());

  // Seed the demo account on first run
  if (!getUsers().length) {
    saveUsers([{ name: 'Demo User', email: 'demo@harbor.app', pass: hash('Demo@1234'), created: Date.now() }]);
  }

  const getSession = () => {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY) || sessionStorage.getItem(SESSION_KEY)); } catch { return null; }
  };

  // ---------- Elements ----------
  const title = $('#title'), subtitle = $('#subtitle'), tabs = $('#tabs'), alertBox = $('#alert');
  const authCard = $('#auth-card'), dashboard = $('#dashboard');
  const forms = { login: $('#login-form'), register: $('#register-form'), forgot: $('#forgot-form') };
  const copy = {
    login:    ['Welcome back', 'Sign in to continue to your dashboard.', 'Harbor – Sign in'],
    register: ['Create your account', 'It takes less than a minute.', 'Harbor – Create account'],
    forgot:   ['Reset your password', 'Confirm your email, then choose a new password.', 'Harbor – Reset password']
  };

  // ---------- UI utilities ----------
  function showAlert(msg, type = 'error') {
    alertBox.textContent = msg; alertBox.className = 'alert ' + type; alertBox.hidden = false;
  }
  const clearAlert = () => { alertBox.hidden = true; };

  function setError(input, msg) {
    const field = input.closest('.field');
    field.classList.toggle('invalid', !!msg);
    $('.err', field).textContent = msg || '';
    return !msg;
  }
  const clearErrors = (form) => $$('.field', form).forEach(f => { f.classList.remove('invalid'); $('.err', f).textContent = ''; });

  function setLoading(form, on, text) {
    const btn = $('.btn', form);
    btn.disabled = on; btn.classList.toggle('loading', on);
    if (text) $('.label', btn).textContent = text;
  }

  // Switch between login / register / forgot
  function showView(name) {
    Object.entries(forms).forEach(([k, f]) => { f.hidden = k !== name; if (k !== name) clearErrors(f); });
    $$('.tab').forEach(t => t.classList.toggle('active', t.dataset.view === name));
    tabs.hidden = name === 'forgot';
    [title.textContent, subtitle.textContent, document.title] = copy[name];
    clearAlert();
  }

  function showAuth() { dashboard.hidden = true; authCard.hidden = false; authCard.style.animation = 'none'; authCard.offsetHeight; authCard.style.animation = ''; }

  // ---------- Validators ----------
  const vEmail = (i) => setError(i, !i.value.trim() ? 'Email is required.' : !EMAIL_RE.test(i.value.trim()) ? 'Enter a valid email address.' : '');
  const vName = (i) => setError(i, i.value.trim().length < 2 ? 'Enter your full name (2+ characters).' : '');
  const vPass = (i) => setError(i, i.value.length < 8 ? 'Password must be at least 8 characters.'
    : !/[A-Za-z]/.test(i.value) || !/\d/.test(i.value) ? 'Include at least one letter and one number.' : '');
  const vConfirm = (i, p) => setError(i, !i.value ? 'Please confirm your password.' : i.value !== p.value ? 'Passwords do not match.' : '');

  // ---------- Navigation: tabs & links ----------
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-view]');
    if (!el) return;
    e.preventDefault();
    showView(el.dataset.view);
    if (el.dataset.view === 'forgot') $('#fp-email').value = $('#login-email').value;
  });

  // Show / hide password
  $$('.eye').forEach(btn => btn.addEventListener('click', () => {
    const input = $('input', btn.parentElement), show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.textContent = show ? 'Hide' : 'Show';
    btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  }));

  // Live password strength meter
  $('#reg-password').addEventListener('input', (e) => {
    const v = e.target.value;
    const score = (v.length >= 8) + (/[A-Z]/.test(v)) + (/\d/.test(v)) + (/[^A-Za-z0-9]/.test(v));
    const bar = $('.meter i');
    bar.style.width = (v ? score * 25 : 0) + '%';
    bar.style.background = ['#d6336c', '#d6336c', '#f08c00', '#12a05c', '#12a05c'][score];
  });

  // Clear a field's error as the user types
  $$('input').forEach(i => i.addEventListener('input', () => { if (i.type !== 'checkbox') setError(i, ''); }));

  // ---------- Login ----------
  forms.login.addEventListener('submit', (e) => {
    e.preventDefault(); clearAlert();
    const email = $('#login-email'), pass = $('#login-password');
    const ok = [vEmail(email), setError(pass, pass.value ? '' : 'Password is required.')].every(Boolean);
    if (!ok) return showAlert('Please fix the highlighted fields.');

    setLoading(forms.login, true, 'Signing in…');
    setTimeout(() => {                                    // simulated network delay
      const user = findUser(email.value);
      if (!user || user.pass !== hash(pass.value)) {
        setLoading(forms.login, false, 'Sign in');
        return showAlert('Incorrect email or password. Please try again.');
      }
      const remember = $('#remember').checked;
      if (remember) localStorage.setItem(REMEMBER_KEY, user.email); else localStorage.removeItem(REMEMBER_KEY);
      const session = JSON.stringify({ email: user.email, at: Date.now(), remember });
      localStorage.removeItem(SESSION_KEY); sessionStorage.removeItem(SESSION_KEY);
      (remember ? localStorage : sessionStorage).setItem(SESSION_KEY, session);
      showAlert('Signed in successfully. Redirecting…', 'success');
      setTimeout(() => { setLoading(forms.login, false, 'Sign in'); forms.login.reset(); renderDashboard(); }, 600);
    }, 900);
  });

  // ---------- Register ----------
  forms.register.addEventListener('submit', (e) => {
    e.preventDefault(); clearAlert();
    const name = $('#reg-name'), email = $('#reg-email'), pass = $('#reg-password'), conf = $('#reg-confirm');
    const ok = [vName(name), vEmail(email), vPass(pass), vConfirm(conf, pass)].every(Boolean);
    if (!ok) return showAlert('Please fix the highlighted fields.');
    if (findUser(email.value)) return showAlert('An account with this email already exists. Try signing in.');

    setLoading(forms.register, true, 'Creating account…');
    setTimeout(() => {
      const users = getUsers();
      users.push({ name: name.value.trim(), email: email.value.trim().toLowerCase(), pass: hash(pass.value), created: Date.now() });
      saveUsers(users);
      setLoading(forms.register, false, 'Create account');
      forms.register.reset(); $('.meter i').style.width = '0';
      showView('login');
      $('#login-email').value = email.value.trim().toLowerCase();
      showAlert('Account created! Sign in with your new credentials.', 'success');
    }, 900);
  });

  // ---------- Forgot / reset password (simulated) ----------
  let resetEmail = null;
  forms.forgot.addEventListener('submit', (e) => {
    e.preventDefault(); clearAlert();
    const email = $('#fp-email'), step2 = $('#fp-step2');

    if (!resetEmail) {                                    // Step 1: find account
      if (!vEmail(email)) return;
      setLoading(forms.forgot, true);
      return setTimeout(() => {
        setLoading(forms.forgot, false);
        if (!findUser(email.value)) return showAlert('No account found with that email.');
        resetEmail = email.value.trim().toLowerCase();
        email.readOnly = true; step2.hidden = false; $('#fp-password').focus();
        $('.label', forms.forgot).textContent = 'Save new password';
        showAlert('Account found. In a real app we would email you a reset link; choose a new password below.', 'success');
      }, 700);
    }
    const pass = $('#fp-password'), conf = $('#fp-confirm');   // Step 2: set password
    if (![vPass(pass), vConfirm(conf, pass)].every(Boolean)) return;
    setLoading(forms.forgot, true);
    setTimeout(() => {
      saveUsers(getUsers().map(u => u.email === resetEmail ? { ...u, pass: hash(pass.value) } : u));
      setLoading(forms.forgot, false);
      resetEmail = null; email.readOnly = false; step2.hidden = true; forms.forgot.reset();
      $('.label', forms.forgot).textContent = 'Find my account';
      showView('login');
      showAlert('Password updated. You can sign in now.', 'success');
    }, 700);
  });

  // ---------- Dashboard & logout ----------
  function renderDashboard() {
    const s = getSession(), user = s && findUser(s.email);
    if (!user) return logout(true);
    const fmt = (t) => new Date(t).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
    $('#dash-greeting').textContent = 'Hello, ' + user.name.split(' ')[0];
    $('#dash-sub').textContent = 'Good to see you again. Here is your overview.';
    $('#p-name').textContent = user.name;
    $('#p-email').textContent = user.email;
    $('#p-since').textContent = new Date(user.created).toLocaleDateString([], { dateStyle: 'long' });
    $('#p-login').textContent = fmt(s.at);
    $('#p-session').textContent = s.remember ? 'Remembered on this device' : 'Ends when you close the tab';
    authCard.hidden = true; dashboard.hidden = false;
    dashboard.style.animation = 'none'; dashboard.offsetHeight; dashboard.style.animation = '';
    document.title = 'Harbor – Dashboard';
  }

  function logout(silent) {
    localStorage.removeItem(SESSION_KEY); sessionStorage.removeItem(SESSION_KEY);
    showAuth(); showView('login');
    if (silent !== true) showAlert('You have been logged out.', 'success');
  }
  $('#logout').addEventListener('click', () => logout());

  // ---------- Init ----------
  const remembered = localStorage.getItem(REMEMBER_KEY);
  if (remembered) { $('#login-email').value = remembered; $('#remember').checked = true; }
  getSession() ? renderDashboard() : showView('login');
})();
