/* NOVA – Registration page (vanilla JS).
   Demo only: localStorage is not secure storage. */
(() => {
  'use strict';

  /* ---------- Configuration ----------
     Paste your Google OAuth Web Client ID here to enable real Google sign-up.
     Leave empty to show setup instructions instead (see README steps in the chat). */
  const GOOGLE_CLIENT_ID = '';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const USERS = 'nova_users', SESSION = 'nova_session';
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const icons = () => lucide.createIcons();

  /* ---------- Storage helpers ---------- */
  const hash = s => { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0; return h.toString(36); }; // demo-only hash
  const getUsers = () => { try { return JSON.parse(localStorage.getItem(USERS)) || []; } catch { return []; } };
  const saveUsers = u => localStorage.setItem(USERS, JSON.stringify(u));
  const byEmail = e => getUsers().find(u => u.email === e.trim().toLowerCase());
  const byUsername = n => getUsers().find(u => u.username.toLowerCase() === n.trim().toLowerCase());

  /* ---------- UI helpers ---------- */
  function toast(msg, type = 'info') {
    const t = Object.assign(document.createElement('div'), { className: 'toast ' + type, textContent: msg });
    $('#toasts').append(t); setTimeout(() => t.remove(), 3800);
  }
  function setError(input, msg) {
    const f = input.closest('.field');
    f.classList.toggle('bad', !!msg); f.classList.toggle('good', !msg && !!input.value);
    $('.err', f).textContent = msg || '';
    return !msg;
  }
  const loading = (form, on, text) => { const b = $('.primary', form); b.disabled = on; b.classList.toggle('loading', on); if (text) $('.label', b).textContent = text; };

  /* ---------- Page transitions between views ---------- */
  function show(name) {
    const cur = $('.view.active'), next = $('#view-' + name);
    if (cur === next) return;
    const swap = () => { cur?.classList.remove('active', 'leave'); next.classList.add('active'); document.title = 'NOVA – ' + { register: 'Create your account', login: 'Log in', welcome: 'Welcome' }[name]; window.scrollTo(0, 0); };
    if (cur) { cur.classList.add('leave'); setTimeout(swap, 220); } else swap();
  }
  document.addEventListener('click', e => {
    const v = e.target.closest('[data-view]'); if (v) { e.preventDefault(); show(v.dataset.view); }
    const m = e.target.closest('[data-modal]'); if (m) { e.preventDefault(); openModal(m.dataset.modal); }
  });

  /* ---------- Terms / Privacy dialog ---------- */
  const docs = {
    terms: ['Terms & Conditions', '<p>By creating a NOVA account you agree to use the service lawfully and keep your login details secure.</p><p>This is a demo project: no real service is provided and accounts exist only in your browser.</p>'],
    privacy: ['Privacy Policy', '<p>NOVA stores the details you enter (name, username, email, phone and a hashed password) only in your browser\'s localStorage.</p><p>Nothing is sent to a server. Use "Log out" or clear site data to remove it at any time.</p>']
  };
  function openModal(k) { $('#modal-title').textContent = docs[k][0]; $('#modal-body').innerHTML = docs[k][1]; $('#modal').showModal(); }
  $('#modal-close').addEventListener('click', () => $('#modal').close());
  $('#modal').addEventListener('click', e => { if (e.target.id === 'modal') e.target.close(); });

  /* ---------- Validators (return true when valid) ---------- */
  const rules = {
    name: i => setError(i, i.value.trim().length < 2 ? 'Enter your full name (at least 2 characters).' : !/^[\p{L}][\p{L} '.-]+$/u.test(i.value.trim()) ? 'Name can only contain letters, spaces and . \' -' : ''),
    username: i => setError(i, !i.value.trim() ? 'Choose a username.' : !/^[A-Za-z0-9_]{3,20}$/.test(i.value.trim()) ? '3–20 characters: letters, numbers or underscores.' : byUsername(i.value) ? 'That username is taken.' : ''),
    email: i => setError(i, !i.value.trim() ? 'Email is required.' : !EMAIL_RE.test(i.value.trim()) ? 'Enter a valid email address.' : byEmail(i.value) ? 'An account with this email already exists.' : ''),
    phone: i => { const d = i.value.replace(/\D/g, ''); return setError(i, !i.value.trim() ? 'Phone number is required.' : !/^\+?[\d\s().-]+$/.test(i.value.trim()) || d.length < 8 || d.length > 15 ? 'Enter a valid phone number (8–15 digits, e.g. +1 555 123 4567).' : ''); },
    password: i => setError(i, !i.value ? 'Password is required.' : i.value.length < 8 ? 'Use at least 8 characters.' : strength(i.value).score < 2 ? 'Too weak: add uppercase letters, numbers or symbols.' : ''),
    confirm: i => setError(i, !i.value ? 'Please confirm your password.' : i.value !== $('#password').value ? 'Passwords do not match.' : ''),
    terms: i => setError(i, i.checked ? '' : 'You must accept the Terms and Privacy Policy.')
  };

  /* ---------- Password strength ---------- */
  function strength(v) {
    const score = Math.min(4, (v.length >= 8) + (v.length >= 12) + (/[a-z]/.test(v) && /[A-Z]/.test(v)) + /\d/.test(v) + /[^A-Za-z0-9]/.test(v) - (v.length < 8 ? 1 : 0));
    return { score: Math.max(0, score), label: ['Very weak', 'Weak', 'Fair', 'Good', 'Strong'][Math.max(0, score)], color: ['#e2506b', '#e2506b', '#e09a28', '#5bb86b', '#2fae7b'][Math.max(0, score)] };
  }
  function paintStrength() {
    const v = $('#password').value, s = strength(v), bar = $('.meter i');
    bar.style.width = v ? (s.score + 1) * 20 + '%' : '0'; bar.style.background = s.color;
    $('#strength-label').textContent = v ? s.label : 'Password strength';
  }

  /* ---------- Show / hide password ---------- */
  $$('.eye').forEach(b => b.addEventListener('click', () => {
    const inp = $('input', b.parentElement), show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    b.innerHTML = `<i data-lucide="${show ? 'eye-off' : 'eye'}"></i>`; b.setAttribute('aria-label', show ? 'Hide password' : 'Show password'); icons();
  }));

  /* ---------- Registration form ---------- */
  const form = $('#reg-form');
  const fields = Object.keys(rules).map(id => $('#' + id));
  fields.forEach(i => {
    i.addEventListener('blur', () => { if (i.value || i.type === 'checkbox') rules[i.id](i); });
    i.addEventListener('input', () => { if (i.closest('.field').classList.contains('bad') || i.id === 'confirm') rules[i.id](i); if (i.id === 'password') { paintStrength(); if ($('#confirm').value) rules.confirm($('#confirm')); } });
  });
  $('#terms').addEventListener('change', e => rules.terms(e.target));

  function clearForm() {
    form.reset(); $$('.field', form).forEach(f => { f.classList.remove('bad', 'good'); $('.err', f).textContent = ''; });
    $$('.eye', form).forEach(b => { $('input', b.parentElement).type = 'password'; b.innerHTML = '<i data-lucide="eye"></i>'; });
    paintStrength(); icons();
  }
  $('#clear-btn').addEventListener('click', () => { clearForm(); toast('Form cleared'); });

  form.addEventListener('submit', e => {
    e.preventDefault();
    const results = fields.map(i => rules[i.id](i));            // run every rule so all errors show at once
    if (results.includes(false)) { toast('Please fix the highlighted fields.', 'error'); $('.bad input', form)?.focus(); return; }
    loading(form, true, 'Creating account…');
    setTimeout(() => {                                          // simulated network delay
      const user = { name: $('#name').value.trim(), username: $('#username').value.trim(), email: $('#email').value.trim().toLowerCase(), phone: $('#phone').value.trim(), pass: hash($('#password').value), created: Date.now(), provider: 'email' };
      saveUsers([...getUsers(), user]);
      loading(form, false, 'Create account'); clearForm();
      toast('Account created successfully!', 'success'); startSession(user);
    }, 1100);
  });

  /* ---------- Login ---------- */
  const lform = $('#login-form');
  lform.addEventListener('submit', e => {
    e.preventDefault();
    const em = $('#l-email'), pw = $('#l-pass');
    const ok = [setError(em, EMAIL_RE.test(em.value.trim()) ? '' : 'Enter a valid email address.'), setError(pw, pw.value ? '' : 'Password is required.')];
    if (ok.includes(false)) return;
    loading(lform, true, 'Logging in…');
    setTimeout(() => {
      const u = byEmail(em.value); loading(lform, false, 'Log in');
      if (!u || u.provider === 'google' || u.pass !== hash(pw.value)) return toast(u?.provider === 'google' ? 'This account uses Google sign-up.' : 'Incorrect email or password.', 'error');
      lform.reset(); toast('Logged in successfully', 'success'); startSession(u);
    }, 800);
  });

  /* ---------- Session + welcome page ---------- */
  function startSession(u) { localStorage.setItem(SESSION, u.email); renderWelcome(u); show('welcome'); }
  function renderWelcome(u) {
    $('#w-title').textContent = `Welcome to NOVA, ${u.name.split(' ')[0]}!`;
    $('#w-sub').textContent = 'Your account is ready. Here are your details:';
    const rows = [['Full name', u.name], ['Username', u.username], ['Email', u.email], ['Phone', u.phone || 'Not provided'], ['Joined', new Date(u.created).toLocaleDateString([], { dateStyle: 'long' })]];
    $('#w-details').innerHTML = rows.map(([k, v]) => `<div><dt>${k}</dt><dd></dd></div>`).join('');
    $$('#w-details dd').forEach((dd, i) => { dd.textContent = rows[i][1]; });   // textContent avoids HTML injection
  }
  $('#logout-btn').addEventListener('click', () => { localStorage.removeItem(SESSION); show('register'); toast('You have been logged out.'); });

  /* ---------- Google sign-up (real OAuth when GOOGLE_CLIENT_ID is set) ---------- */
  function googleSignUp() {
    if (!GOOGLE_CLIENT_ID) { openModalHtml('Set up Google sign-up', '<p>Create an OAuth <b>Web client ID</b> in Google Cloud Console (APIs &amp; Services → Credentials), add your site origin (for example <code>http://localhost:5500</code>) under Authorized JavaScript origins, then paste the ID into <code>GOOGLE_CLIENT_ID</code> at the top of <code>script.js</code>.</p><p>Google sign-in does not work from <code>file://</code>; serve the folder with Live Server or <code>python -m http.server</code>.</p>'); return; }
    const start = () => google.accounts.oauth2.initTokenClient({
      client_id: GOOGLE_CLIENT_ID, scope: 'openid email profile',
      callback: async res => {
        if (res.error) return toast('Google sign-up was cancelled.', 'error');
        try {
          const p = await (await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: 'Bearer ' + res.access_token } })).json();
          let u = byEmail(p.email);
          if (!u) { u = { name: p.name, username: p.email.split('@')[0], email: p.email.toLowerCase(), phone: '', pass: '', created: Date.now(), provider: 'google' }; saveUsers([...getUsers(), u]); toast('Account created with Google!', 'success'); }
          else toast('Welcome back! Signed in with Google.', 'success');
          startSession(u);
        } catch { toast('Could not reach Google. Try again.', 'error'); }
      }
    }).requestAccessToken();
    if (window.google?.accounts) return start();
    const s = Object.assign(document.createElement('script'), { src: 'https://accounts.google.com/gsi/client', onload: start, onerror: () => toast('Could not load Google sign-in.', 'error') });
    document.head.append(s);
  }
  function openModalHtml(t, h) { $('#modal-title').textContent = t; $('#modal-body').innerHTML = h; $('#modal').showModal(); }
  $('#google-btn').addEventListener('click', googleSignUp);

  /* ---------- Init ---------- */
  icons();
  const current = localStorage.getItem(SESSION) && byEmail(localStorage.getItem(SESSION));
  if (current) { renderWelcome(current); show('welcome'); }
})();
